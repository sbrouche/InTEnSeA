#include <QApplication>
#include "fenetre.h"


int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    QString path = app.applicationDirPath();

    QStandardPaths::writableLocation(QStandardPaths::DesktopLocation);

    MemoireService mem(path);
    AttentionService att(path);

    Fenetre f(&mem, &att);


    return app.exec();
}



